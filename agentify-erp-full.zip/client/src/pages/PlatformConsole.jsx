import { useCallback, useEffect, useState } from 'react';
import { Card, ConfirmDialog, Empty, Field, Loading, Modal, StatusBadge, Tabs, TextInput, Toggle } from '../components/ui.jsx';
import { api } from '../api.js';
import { useToast } from '../context.jsx';
import TwoFactor from '../components/TwoFactor.jsx';

const A = '/api/platform/admin';
const PLANS = ['starter', 'growth', 'enterprise'];
const SLOT_LABEL = (s) => s.replace('_', ' · ').replace(/^./, (c) => c.toUpperCase());

function SignIn({ onDone }) {
  const [f, setF] = useState({ email: '', password: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [mfa, setMfa] = useState(null);
  const [code, setCode] = useState('');
  const go = async (e) => {
    e.preventDefault(); setBusy(true); setErr('');
    try {
      const out = mfa ? await api.post(`${A}/login/mfa`, { mfa_token: mfa, code }) : await api.post(`${A}/login`, f);
      if (out.mfa_required) setMfa(out.mfa_token); else onDone();
    } catch (x) { setErr(x.message); if (mfa && /expired/i.test(x.message)) setMfa(null); } finally { setBusy(false); }
  };
  return (
    <div className="empty" style={{ paddingTop: 80 }}>
      <form onSubmit={go} style={{ width: 340, textAlign: 'left' }}>
        <h2 style={{ textAlign: 'center' }}>Platform console</h2>
        {err && <div className="alert err">{err}</div>}
        {mfa ? <Field label="Authenticator code" hint="Or one of your recovery codes."><TextInput autoComplete="one-time-code" value={code} onChange={setCode} autoFocus /></Field> : <>
          <Field label="Email"><TextInput type="email" value={f.email} onChange={(v) => setF({ ...f, email: v })} autoFocus /></Field>
          <Field label="Password"><TextInput type="password" value={f.password} onChange={(v) => setF({ ...f, password: v })} /></Field></>}
        <button className="btn primary" style={{ width: '100%' }} disabled={busy}>{busy ? 'Signing in…' : mfa ? 'Verify' : 'Sign in'}</button>
      </form>
    </div>
  );
}

function Workspaces() {
  const toast = useToast();
  const [rows, setRows] = useState(null);
  const [edit, setEdit] = useState(null);
  const load = useCallback(() => api.get('/api/platform/tenants').then(setRows).catch((e) => toast(e.message, 'err')), [toast]);
  useEffect(() => { load(); }, [load]);
  if (!rows) return <Loading />;
  const toggle = async (t) => { try { await api.post(`/api/platform/tenants/${t.id}/status`, { status: t.status === 'active' ? 'suspended' : 'active' }); load(); } catch (e) { toast(e.message, 'err'); } };
  const savePlan = async () => {
    try { await api.post(`/api/platform/tenants/${edit.id}/subscription`, { plan: edit.plan, status: edit.sub, interval: edit.interval, period_end: edit.period_end || undefined }); setEdit(null); load(); toast('Plan updated'); } catch (e) { toast(e.message, 'err'); }
  };
  return (
    <Card flush>
      {!rows.length ? <Empty title="No workspaces yet" /> : (
        <div className="table-wrap"><table className="t"><thead><tr><th>Workspace</th><th>Owner</th><th>Plan</th><th>Billing</th><th>Status</th><th /></tr></thead><tbody>
          {rows.map((t) => (
            <tr key={t.id}>
              <td><b>{t.name}</b><div className="muted">{t.slug}{t.custom_domain ? ` · ${t.custom_domain}` : ''}</div></td>
              <td>{t.owner_email || '—'}</td>
              <td style={{ textTransform: 'capitalize' }}>{t.plan}</td>
              <td><StatusBadge status={t.subscription_status} />{t.current_period_end && <div className="muted">to {String(t.current_period_end).slice(0, 10)}</div>}</td>
              <td><StatusBadge status={t.status} /></td>
              <td className="right nowrap">
                {!t.is_legacy && <button className="btn sm" onClick={() => setEdit({ id: t.id, name: t.name, plan: PLANS.includes(t.plan) ? t.plan : 'starter', sub: 'active', interval: t.billing_interval || 'month', period_end: '' })}>Set plan</button>}{' '}
                {!t.is_legacy && <button className="btn sm" onClick={() => toggle(t)}>{t.status === 'active' ? 'Suspend' : 'Activate'}</button>}
              </td>
            </tr>
          ))}
        </tbody></table></div>
      )}
      {edit && (
        <Modal title={`Set plan · ${edit.name}`} onClose={() => setEdit(null)} footer={<><button className="btn" onClick={() => setEdit(null)}>Cancel</button><button className="btn primary" onClick={savePlan}>Save</button></>}>
          <Field label="Plan"><select className="input" value={edit.plan} onChange={(e) => setEdit({ ...edit, plan: e.target.value })}>{PLANS.map((p) => <option key={p}>{p}</option>)}</select></Field>
          <Field label="Status"><select className="input" value={edit.sub} onChange={(e) => setEdit({ ...edit, sub: e.target.value })}>{['active', 'trialing', 'past_due', 'canceled'].map((p) => <option key={p}>{p}</option>)}</select></Field>
          <Field label="Interval"><select className="input" value={edit.interval} onChange={(e) => setEdit({ ...edit, interval: e.target.value })}><option value="month">Monthly</option><option value="year">Yearly</option></select></Field>
          <Field label="Paid until" hint="YYYY-MM-DD"><TextInput value={edit.period_end} onChange={(v) => setEdit({ ...edit, period_end: v })} placeholder="2026-12-31" /></Field>
        </Modal>
      )}
    </Card>
  );
}

function Payments() {
  const toast = useToast();
  const [rows, setRows] = useState(null);
  const [note, setNote] = useState('');
  const [ask, setAsk] = useState(null);
  const load = useCallback(() => api.get('/api/platform/payments').then(setRows).catch((e) => toast(e.message, 'err')), [toast]);
  useEffect(() => { load(); }, [load]);
  if (!rows) return <Loading />;
  const decide = async () => {
    try { await api.post(`/api/platform/payments/${ask.s.id}/${ask.act}`, { note }); setAsk(null); setNote(''); load(); toast(ask.act === 'approve' ? 'Payment approved' : 'Payment rejected'); } catch (e) { toast(e.message, 'err'); }
  };
  return (
    <Card flush>
      {!rows.length ? <Empty title="No payments submitted" hint="Customers who pay by Raast, Easypaisa, JazzCash, SadaPay, NayaPay or bank transfer appear here." /> : (
        <div className="table-wrap"><table className="t"><thead><tr><th>Date</th><th>Workspace</th><th>Plan</th><th>Method</th><th>Amount</th><th>Reference</th><th>Status</th><th /></tr></thead><tbody>
          {rows.map((s) => (
            <tr key={s.id}>
              <td className="nowrap">{String(s.created_at).slice(0, 10)}</td><td><b>{s.tenant_name}</b><div className="muted">{s.slug}</div></td>
              <td style={{ textTransform: 'capitalize' }}>{s.plan} / {s.interval}</td><td>{s.method}</td><td className="mono nowrap">{s.currency} {Number(s.amount).toLocaleString()}</td>
              <td className="mono">{s.reference}{s.note && <div className="muted">{s.note}</div>}</td><td><StatusBadge status={s.status} /></td>
              <td className="right nowrap">{s.status === 'pending' && <><button className="btn sm primary" onClick={() => setAsk({ s, act: 'approve' })}>Approve</button>{' '}<button className="btn sm" onClick={() => setAsk({ s, act: 'reject' })}>Reject</button></>}</td>
            </tr>
          ))}
        </tbody></table></div>
      )}
      {ask && (
        <Modal title={`${ask.act === 'approve' ? 'Approve' : 'Reject'} payment ${ask.s.reference}`} onClose={() => setAsk(null)} footer={<><button className="btn" onClick={() => setAsk(null)}>Cancel</button><button className={`btn ${ask.act === 'approve' ? 'primary' : 'danger'}`} onClick={decide}>{ask.act === 'approve' ? 'Approve' : 'Reject'}</button></>}>
          <p>{ask.act === 'approve' ? 'Confirm the money has arrived in your account. The plan starts for one period and the customer is emailed.' : 'The customer is told this payment was not accepted.'}</p>
          <Field label="Note to customer (optional)"><TextInput value={note} onChange={setNote} /></Field>
        </Modal>
      )}
    </Card>
  );
}

const keyField = (m, k) => `${m}.${k}`;

function StripeSettings() {
  const toast = useToast();
  const [v, setV] = useState(null);
  const [form, setForm] = useState({});
  const [result, setResult] = useState({});
  const load = useCallback(() => api.get(`${A}/settings/stripe`).then((d) => { setV(d); setForm({}); }).catch((e) => toast(e.message, 'err')), [toast]);
  useEffect(() => { load(); }, [load]);
  if (!v) return <Loading />;
  const set = (k, val) => setForm((f) => ({ ...f, [k]: val }));
  const save = async () => {
    const body = { mode: form.mode ?? v.mode, test: {}, live: {}, prices: { test: {}, live: {} } };
    for (const [k, val] of Object.entries(form)) {
      const [m, kind, slot] = k.split('.');
      if (kind === 'price') body.prices[m][slot] = val === '' ? null : val;
      else if (m === 'test' || m === 'live') body[m][kind] = val;
    }
    try { setV(await api.put(`${A}/settings/stripe`, body)); setForm({}); toast('Stripe settings saved'); } catch (e) { toast(e.message, 'err'); }
  };
  const test = async (m) => {
    setResult((r) => ({ ...r, [m]: { busy: true } }));
    let out;
    try { out = await api.post(`${A}/settings/stripe/test`, { mode: m }); } catch (e) { out = { ok: false, error: e.message }; }
    setResult((r) => ({ ...r, [m]: out }));
  };
  const mode = form.mode ?? v.mode;
  const dirty = Object.keys(form).length > 0;
  const keyIn = (m, k, label, ph) => (
    <Field label={label} hint={k === 'publishable_key' ? (v.modes[m][k] ? 'Saved (type to replace)' : 'Not set') : (v.modes[m][k].set ? `Saved, ends ${v.modes[m][k].hint} (leave blank to keep)` : 'Not set')}>
      <TextInput type={k === 'publishable_key' ? 'text' : 'password'} autoComplete="off" value={form[keyField(m, k)] ?? ''} placeholder={k === 'publishable_key' ? (v.modes[m][k] || ph) : ph} onChange={(val) => set(keyField(m, k), val)} />
    </Field>
  );
  return (
    <>
      <Card title="Active mode">
        <p className="muted">Test mode uses Stripe test cards and no real money. Switch to Live only after the live keys, prices and webhook are saved.</p>
        <Tabs tabs={[{ key: 'test', label: 'Test mode' }, { key: 'live', label: 'Live mode' }]} value={mode} onChange={(m) => set('mode', m)} />
        <p>Customers are charged in <b>{v.mode}</b> mode right now{form.mode && form.mode !== v.mode ? ` (will switch to ${form.mode} on save)` : ''}. {v.ready ? '' : 'Stripe is not ready: a secret key and at least one price are needed.'}</p>
      </Card>
      {['test', 'live'].map((m) => (
        <Card key={m} title={`${m === 'test' ? 'Test' : 'Live'} keys`}>
          {keyIn(m, 'secret_key', 'Secret key', `sk_${m}_…`)}
          {keyIn(m, 'publishable_key', 'Publishable key', `pk_${m}_…`)}
          {keyIn(m, 'webhook_secret', 'Webhook signing secret', 'whsec_…')}
          <h4>Price IDs</h4>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(200px,1fr))', gap: 12 }}>
            {Object.keys(v.modes[m].prices).map((slot) => (
              <Field key={slot} label={SLOT_LABEL(slot)}><TextInput value={form[`${m}.price.${slot}`] ?? v.modes[m].prices[slot] ?? ''} placeholder="price_…" onChange={(val) => set(`${m}.price.${slot}`, val)} /></Field>
            ))}
          </div>
          <button className="btn" style={{ marginTop: 12 }} onClick={() => test(m)} disabled={result[m]?.busy || dirty} title={dirty ? 'Save first' : ''}>Test connection</button>
          {result[m] && !result[m].busy && <span style={{ marginLeft: 12 }} className={result[m].ok ? 'ok' : 'err'}>{result[m].ok ? `Connected${result[m].account ? ` to ${result[m].account}` : ''}` : result[m].error}</span>}
        </Card>
      ))}
      <Card title="Webhook">
        <p>In Stripe → Developers → Webhooks, add this endpoint and select these events, then paste its signing secret above.</p>
        <p><code>{v.webhook_url}</code></p>
        <p className="muted">{v.events.join(', ')}</p>
      </Card>
      <div style={{ padding: '16px 0' }}><button className="btn primary" disabled={!dirty} onClick={save}>Save Stripe settings</button></div>
    </>
  );
}

function LocalAccounts() {
  const toast = useToast();
  const [d, setD] = useState(null);
  const [edit, setEdit] = useState(null);
  const [del, setDel] = useState(null);
  const load = useCallback(() => api.get(`${A}/payment-accounts`).then(setD).catch((e) => toast(e.message, 'err')), [toast]);
  useEffect(() => { load(); }, [load]);
  if (!d) return <Loading />;
  const save = async () => {
    const { id, label, ...body } = edit;
    try { if (id) await api.put(`${A}/payment-accounts/${id}`, body); else await api.post(`${A}/payment-accounts`, body); setEdit(null); load(); toast('Saved'); } catch (e) { toast(e.message, 'err'); }
  };
  const flip = async (a) => { try { await api.put(`${A}/payment-accounts/${a.id}`, { active: !a.active }); load(); } catch (e) { toast(e.message, 'err'); } };
  return (
    <Card title="Where customers send money" actions={<button className="btn primary sm" onClick={() => setEdit({ method: Object.keys(d.methods)[0], account: '', account_name: '', note: '', active: true })}>Add account</button>} flush>
      {!d.accounts.length ? <Empty title="No accounts yet" hint="Customers only see the local payment methods you add here." /> : (
        <div className="table-wrap"><table className="t"><thead><tr><th>Method</th><th>Account / ID</th><th>Account title</th><th>Note</th><th>Shown</th><th /></tr></thead><tbody>
          {d.accounts.map((a) => (
            <tr key={a.id}>
              <td><b>{a.label}</b></td><td className="mono">{a.account}</td><td>{a.account_name || '—'}</td><td>{a.note || '—'}</td>
              <td><Toggle value={a.active} onChange={() => flip(a)} /></td>
              <td className="right nowrap"><button className="btn sm" onClick={() => setEdit({ ...a })}>Edit</button>{' '}<button className="btn sm danger" onClick={() => setDel(a)}>Delete</button></td>
            </tr>
          ))}
        </tbody></table></div>
      )}
      {edit && (
        <Modal title={edit.id ? 'Edit account' : 'Add account'} onClose={() => setEdit(null)} footer={<><button className="btn" onClick={() => setEdit(null)}>Cancel</button><button className="btn primary" onClick={save}>Save</button></>}>
          <Field label="Method"><select className="input" value={edit.method} onChange={(e) => setEdit({ ...edit, method: e.target.value })}>{Object.entries(d.methods).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></Field>
          <Field label="Account number / IBAN / Raast ID" required><TextInput value={edit.account} onChange={(v) => setEdit({ ...edit, account: v })} /></Field>
          <Field label="Account title"><TextInput value={edit.account_name} onChange={(v) => setEdit({ ...edit, account_name: v })} /></Field>
          <Field label="Note shown to customer"><TextInput value={edit.note} onChange={(v) => setEdit({ ...edit, note: v })} placeholder="e.g. Send from your own account and keep the receipt" /></Field>
          <Toggle value={edit.active} onChange={(v) => setEdit({ ...edit, active: v })} label="Show to customers" />
        </Modal>
      )}
      {del && <ConfirmDialog title="Delete account?" message={`${del.label} ${del.account} will no longer be offered to customers. Past payments are unaffected.`} confirmLabel="Delete" danger onCancel={() => setDel(null)} onConfirm={async () => { try { await api.del(`${A}/payment-accounts/${del.id}`); setDel(null); load(); } catch (e) { toast(e.message, 'err'); } }} />}
    </Card>
  );
}

const fmtBytes = (n) => (n > 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1e3))} KB`);

function Backups() {
  const toast = useToast();
  const [d, setD] = useState(null);
  const [busy, setBusy] = useState(false);
  const load = useCallback(() => api.get(`${A}/backups`).then(setD).catch((e) => toast(e.message, 'err')), [toast]);
  useEffect(() => { load(); }, [load]);
  if (!d) return <Loading />;
  const run = async () => { setBusy(true); try { const r = await api.post(`${A}/backups/run`); toast(`Backed up ${r.tenants} workspace(s)`); load(); } catch (e) { toast(e.message, 'err'); } finally { setBusy(false); } };
  return (
    <>
      <Card title="Automatic backups" actions={<button className="btn primary sm" onClick={run} disabled={busy}>{busy ? 'Backing up…' : 'Back up now'}</button>}>
        <p>{d.enabled ? `A snapshot of the platform and every workspace database is taken every ${d.every_hours} hours and the newest ${d.keep} are kept.` : 'Automatic backups are turned off (BACKUP_ENABLED=0).'} Uploaded files {d.uploads ? 'are included.' : 'are not included (set BACKUP_UPLOADS=1).'}</p>
        <p className="muted">Folder on the server: <code>{d.dir}</code>. Copy it off the server regularly. The encryption key (<code>ERP_SECRETS_KEY</code> or <code>data/.secrets-key</code>) is deliberately not inside the backups: store it separately, or the saved Stripe keys cannot be read after a restore.</p>
      </Card>
      <Card flush>
        {!d.backups.length ? <Empty title="No backups yet" hint="The first one runs about a minute after the server starts, or press Back up now." /> : (
          <div className="table-wrap"><table className="t"><thead><tr><th>Backup</th><th>Taken</th><th>Workspaces</th><th>Size</th><th>Problems</th></tr></thead><tbody>
            {d.backups.map((b) => <tr key={b.name}><td className="mono">{b.name}</td><td>{b.created_at ? String(b.created_at).replace('T', ' ').slice(0, 16) : 'unfinished'}</td><td>{b.tenants ?? '—'}</td><td>{fmtBytes(b.bytes)}</td><td>{b.errors.length ? b.errors.join('; ') : 'None'}</td></tr>)}
          </tbody></table></div>
        )}
      </Card>
    </>
  );
}

export default function PlatformConsole() {
  const [me, setMe] = useState(undefined);
  const [tab, setTab] = useState('workspaces');
  const [pw, setPw] = useState(null);
  const toast = useToast();
  const loadMe = useCallback(() => api.get(`${A}/me`).then(setMe).catch(() => setMe(null)), []);
  useEffect(() => { loadMe(); }, [loadMe]);
  if (me === undefined) return <Loading />;
  if (!me) return <SignIn onDone={loadMe} />;
  const out = async () => { try { await api.post(`${A}/logout`); } catch { /* ignore */ } setMe(null); };
  const changePw = async () => { try { await api.post(`${A}/change-password`, pw); setPw(null); toast('Password changed'); } catch (e) { toast(e.message, 'err'); } };
  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', padding: '24px 16px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
        <h1 style={{ margin: 0 }}>Platform console</h1>
        <span>{me.email} <button className="btn sm" onClick={() => setPw({ current: '', next: '' })}>Change password</button>{' '}<button className="btn sm" onClick={out}>Sign out</button></span>
      </div>
      <Tabs tabs={[{ key: 'workspaces', label: 'Workspaces' }, { key: 'payments', label: 'Payments' }, { key: 'stripe', label: 'Stripe settings' }, { key: 'accounts', label: 'Local payment accounts' }, { key: 'backups', label: 'Backups' }, { key: 'security', label: 'Security' }]} value={tab} onChange={setTab} />
      <div style={{ marginTop: 16 }}>
        {tab === 'workspaces' && <Workspaces />}{tab === 'payments' && <Payments />}{tab === 'stripe' && <StripeSettings />}{tab === 'accounts' && <LocalAccounts />}{tab === 'backups' && <Backups />}{tab === 'security' && <TwoFactor base={`${A}/2fa`} />}
      </div>
      {pw && (
        <Modal title="Change password" onClose={() => setPw(null)} footer={<><button className="btn" onClick={() => setPw(null)}>Cancel</button><button className="btn primary" onClick={changePw}>Change</button></>}>
          <Field label="Current password"><TextInput type="password" value={pw.current} onChange={(v) => setPw({ ...pw, current: v })} /></Field>
          <Field label="New password (10+ characters)"><TextInput type="password" value={pw.next} onChange={(v) => setPw({ ...pw, next: v })} /></Field>
        </Modal>
      )}
    </div>
  );
}
