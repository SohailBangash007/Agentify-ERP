// Who may use the platform admin console / operator API. Two ways in:
//   * a signed-in platform admin (cookie session, created from PLATFORM_ADMIN_EMAIL / PLATFORM_ADMIN_PASSWORD on first start)
//   * the bearer token ERP_PLATFORM_ADMIN_TOKEN, for scripts
// Platform admins are a separate set of accounts from any workspace's users, and the console is only reachable on the
// platform's own domain, never on a customer's workspace address.
import crypto from 'node:crypto';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { platformDb, isMultiTenant, BASE_DOMAIN } from '../platform.js';
import { secretsKey, encrypt, decrypt } from './platformConfig.js';
import { newSecret, verifyCode, otpauthUrl, qrDataUrl, newRecoveryCodes, useRecoveryCode } from './totp.js';
import { HttpError, bad } from '../util.js';

export const COOKIE = 'platform_token';
const jwtSecret = () => crypto.createHmac('sha256', secretsKey()).update('platform-session').digest();

/** Create the first admin from the environment, once, when none exists yet. */
export function ensureFirstAdmin() {
  const email = process.env.PLATFORM_ADMIN_EMAIL, pw = process.env.PLATFORM_ADMIN_PASSWORD;
  const db = platformDb();
  if (!email || !pw || db.prepare('SELECT 1 FROM platform_admins LIMIT 1').get()) return;
  if (pw.length < 10) { console.error('PLATFORM_ADMIN_PASSWORD must be at least 10 characters; no platform admin was created'); return; }
  db.prepare('INSERT INTO platform_admins(email,name,password_hash) VALUES(?,?,?)').run(email.toLowerCase(), process.env.PLATFORM_ADMIN_NAME || 'Platform admin', bcrypt.hashSync(pw, 10));
}

/** The console lives on the platform domain only (or anywhere in single-tenant mode). */
export function onPlatformHost(req) {
  if (!isMultiTenant()) return true;
  const h = String(req.hostname || '').toLowerCase();
  return h === BASE_DOMAIN || h === `www.${BASE_DOMAIN}`;
}

export function login(email, password) {
  const a = platformDb().prepare('SELECT * FROM platform_admins WHERE email=?').get(String(email || '').trim());
  // compare even when the account does not exist so timing does not reveal which emails are admins
  const ok = bcrypt.compareSync(String(password || ''), a?.password_hash || '$2a$10$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvali');
  if (!a || !ok) throw new HttpError(401, 'Invalid credentials');
  if (a.totp_enabled) return { mfa_token: jwt.sign({ aid: a.id }, jwtSecret(), { expiresIn: '5m', audience: 'platform-mfa' }) };
  return issueSession(a);
}

function issueSession(a) {
  platformDb().prepare("UPDATE platform_admins SET last_login=datetime('now') WHERE id=?").run(a.id);
  return { admin: { id: a.id, email: a.email, name: a.name }, token: jwt.sign({ aid: a.id, tv: a.token_version, aud: 'platform' }, jwtSecret(), { expiresIn: '8h' }) };
}

/** Second sign-in step: authenticator code or a one-time recovery code. */
export function loginMfa(mfaToken, code) {
  let aid;
  try { aid = jwt.verify(String(mfaToken || ''), jwtSecret(), { audience: 'platform-mfa' }).aid; } catch { throw new HttpError(401, 'This sign-in expired. Enter your password again.'); }
  const db = platformDb();
  const a = db.prepare('SELECT * FROM platform_admins WHERE id=? AND totp_enabled=1').get(aid);
  if (!a) throw new HttpError(401, 'This sign-in expired. Enter your password again.');
  const c = String(code || '').trim();
  const step = verifyCode(decrypt(a.totp_secret), c, a.totp_last_step);
  if (step) db.prepare('UPDATE platform_admins SET totp_last_step=? WHERE id=?').run(step, a.id);
  else {
    const left = useRecoveryCode(JSON.parse(a.recovery_codes || '[]'), c);
    if (!left) throw new HttpError(401, 'That code is not right');
    db.prepare('UPDATE platform_admins SET recovery_codes=? WHERE id=?').run(JSON.stringify(left), a.id);
  }
  return issueSession(a);
}

export const twofaStatus = (id) => { const a = platformDb().prepare('SELECT totp_enabled, recovery_codes FROM platform_admins WHERE id=?').get(id); return { enabled: !!a.totp_enabled, recovery_left: a.totp_enabled ? JSON.parse(a.recovery_codes || '[]').length : 0 }; };
export async function twofaSetup(admin) {
  const a = platformDb().prepare('SELECT totp_enabled FROM platform_admins WHERE id=?').get(admin.id);
  if (a.totp_enabled) throw bad('Two-factor sign-in is already on. Turn it off first to set it up again.');
  const secret = newSecret();
  platformDb().prepare('UPDATE platform_admins SET totp_secret=?, totp_last_step=0 WHERE id=?').run(encrypt(secret), admin.id);
  const url = otpauthUrl(secret, admin.email, 'Agentify ERP platform');
  return { secret, otpauth: url, qr: await qrDataUrl(url) };
}
export function twofaEnable(id, code) {
  const a = platformDb().prepare('SELECT * FROM platform_admins WHERE id=?').get(id);
  if (a.totp_enabled) throw bad('Two-factor sign-in is already on');
  if (!a.totp_secret) throw bad('Start the setup first');
  const step = verifyCode(decrypt(a.totp_secret), code);
  if (!step) throw bad('That code is not right. Check the time on your phone and try the next code.');
  const rc = newRecoveryCodes();
  platformDb().prepare('UPDATE platform_admins SET totp_enabled=1, totp_last_step=?, recovery_codes=? WHERE id=?').run(step, JSON.stringify(rc.hashes), id);
  return rc.codes;
}
export function twofaDisable(id, password, code) {
  const a = platformDb().prepare('SELECT * FROM platform_admins WHERE id=?').get(id);
  if (!a.totp_enabled) return;
  if (!bcrypt.compareSync(String(password || ''), a.password_hash)) throw new HttpError(403, 'Password is incorrect');
  const c = String(code || '').trim();
  if (!verifyCode(decrypt(a.totp_secret), c, a.totp_last_step) && !useRecoveryCode(JSON.parse(a.recovery_codes || '[]'), c)) throw new HttpError(403, 'That code is not right');
  platformDb().prepare('UPDATE platform_admins SET totp_enabled=0, totp_secret=NULL, recovery_codes=NULL WHERE id=?').run(id);
}

export function changePassword(adminId, current, next) {
  const a = platformDb().prepare('SELECT * FROM platform_admins WHERE id=?').get(adminId);
  if (!bcrypt.compareSync(String(current || ''), a.password_hash)) throw bad('Current password is incorrect');
  if (String(next || '').length < 10) throw bad('New password must be at least 10 characters');
  platformDb().prepare('UPDATE platform_admins SET password_hash=?, token_version=token_version+1 WHERE id=?').run(bcrypt.hashSync(String(next), 10), a.id);
  return issueSession(platformDb().prepare('SELECT * FROM platform_admins WHERE id=?').get(a.id));
}

function sessionAdmin(req) {
  const tok = req.cookies?.[COOKIE];
  if (!tok) return null;
  try {
    const p = jwt.verify(tok, jwtSecret(), { audience: 'platform' });
    const a = platformDb().prepare('SELECT id,email,name,token_version FROM platform_admins WHERE id=?').get(p.aid);
    return a && a.token_version === p.tv ? a : null;
  } catch { return null; }
}

/** Sets req.operator = { email, via }. 404 on a workspace address, 401 without credentials. */
export function requireOperator(req, _res, next) {
  if (!onPlatformHost(req)) return next(new HttpError(404, 'Not found'));
  const want = process.env.ERP_PLATFORM_ADMIN_TOKEN;
  const got = (req.headers.authorization || '').replace(/^Bearer /, '');
  if (want && got) {
    const a = Buffer.from(got), b = Buffer.from(want);
    if (a.length === b.length && crypto.timingSafeEqual(a, b)) { req.operator = { email: 'api-token', via: 'token' }; return next(); }
  }
  const admin = sessionAdmin(req);
  if (!admin) return next(new HttpError(401, 'Platform admin sign-in required'));
  // cookie sessions are subject to the same CSRF rule as the rest of the app
  if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method) && req.headers['x-requested-with'] !== 'ERP') return next(new HttpError(403, 'CSRF check failed'));
  req.operator = { id: admin.id, email: admin.email, name: admin.name, via: 'session' };
  next();
}
