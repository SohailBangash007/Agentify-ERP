// Billing is provider-agnostic. A provider only has to do two things: send the customer to a hosted checkout, and call
// our webhook (below) when the subscription changes. Nothing here talks to a payment API directly, so any provider that
// supports hosted payment links plus webhooks (Paddle, Lemon Squeezy, Safepay, Stripe, ...) fits with a small adapter.
//
//   BILLING_PROVIDER=manual   (default) no online checkout; the operator records payments (bank transfer, invoices)
//   BILLING_PROVIDER=generic  hosted payment links from env: BILLING_CHECKOUT_URL_<PLAN>_<MONTH|YEAR>, e.g.
//                             BILLING_CHECKOUT_URL_GROWTH_MONTH=https://pay.example.com/growth-monthly
//                             and a signed webhook to POST /api/platform/billing/webhook/generic
//   BILLING_WEBHOOK_SECRET    HMAC secret the provider (or its adapter) signs webhooks with
import crypto from 'node:crypto';
import { PLANS, GRACE_DAYS } from './plans.js';
import { bad, HttpError } from '../util.js';
import { platformDb, getTenant, getTenantBySlug, logTenantEvent } from '../platform.js';
import * as stripe from './stripe.js';
import { sendMail, layout } from './mailer.js';

export const providerName = () => (process.env.BILLING_PROVIDER || 'manual').toLowerCase();

/** Where to send the customer to pay for `plan`. Returns { mode:'redirect', url } or { mode:'manual', instructions }. */
export function startCheckout(tenant, { plan, interval = 'month', email }) {
  if (!PLANS[plan]) throw bad('Unknown plan');
  if (!['month', 'year'].includes(interval)) throw bad('Interval must be month or year');
  if (providerName() === 'generic') {
    const base = process.env[`BILLING_CHECKOUT_URL_${plan.toUpperCase()}_${interval.toUpperCase()}`];
    if (!base) throw new HttpError(503, 'Online checkout is not configured for this plan yet');
    const u = new URL(base);
    u.searchParams.set('client_reference_id', `${tenant.id}`); // echoed back in the webhook so we know whose payment it was
    if (email) u.searchParams.set('email', email);
    return { mode: 'redirect', url: u.toString() };
  }
  return { mode: 'manual', instructions: process.env.BILLING_MANUAL_INSTRUCTIONS || 'Online payment is not enabled yet. Contact us to activate your plan by bank transfer or invoice.' };
}

/** Constant-time check of `X-Signature: sha256=<hex>` over the exact bytes received. */
export function verifySignature(rawBody, header) {
  const secret = process.env.BILLING_WEBHOOK_SECRET;
  if (!secret) throw new HttpError(503, 'Billing webhooks are not configured');
  if (!rawBody || !header) return false;
  const want = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
  const got = String(header).replace(/^sha256=/, '');
  const a = Buffer.from(want), b = Buffer.from(got);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const iso = (d) => String(d || '').slice(0, 10) || null;
const addDays = (n) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);

/**
 * Apply one normalised event:
 *   { id, type, tenant_id | tenant_slug, plan?, interval?, period_end?, customer_id?, subscription_id?, invoice?: { id, amount, currency, status, url, period_start, period_end } }
 * Types: subscription.activated | subscription.renewed | subscription.canceled | payment.failed | invoice.paid
 * Replays are ignored (provider + event id is unique), so a provider retrying a webhook is harmless.
 */
export function applyBillingEvent(provider, ev) {
  if (!ev?.id || !ev?.type) throw bad('Event id and type are required');
  const tenant = ev.tenant_id ? getTenant(Number(ev.tenant_id)) : ev.tenant_slug ? getTenantBySlug(ev.tenant_slug) : null;
  if (!tenant) throw new HttpError(404, 'Unknown tenant');
  if (tenant.is_legacy) throw bad('The original workspace is not billed');
  const db = platformDb();
  db.exec('BEGIN IMMEDIATE');
  try {
    const dup = db.prepare('INSERT OR IGNORE INTO billing_events(provider,event_id,tenant_id,type,payload) VALUES(?,?,?,?,?)').run(provider, String(ev.id), tenant.id, ev.type, JSON.stringify(ev));
    if (!dup.changes) { db.exec('COMMIT'); return { applied: false, duplicate: true, tenant }; }
    const set = (fields) => {
      const keys = Object.keys(fields);
      db.prepare(`UPDATE tenants SET ${keys.map((k) => `${k}=?`).join(',')}, updated_at=datetime('now') WHERE id=?`).run(...keys.map((k) => fields[k]), tenant.id);
    };
    const ids = { billing_provider: provider, ...(ev.customer_id ? { provider_customer_id: String(ev.customer_id) } : {}), ...(ev.subscription_id ? { provider_subscription_id: String(ev.subscription_id) } : {}) };
    switch (ev.type) {
      case 'subscription.activated':
      case 'subscription.renewed': {
        const plan = ev.plan || tenant.plan;
        if (!PLANS[plan]) throw bad(`Unknown plan: ${plan}`);
        set({ ...ids, plan, subscription_status: 'active', current_period_end: iso(ev.period_end), billing_interval: ev.interval === 'year' ? 'year' : 'month', grace_until: null });
        break;
      }
      case 'subscription.canceled':
        set({ ...ids, subscription_status: 'canceled', current_period_end: iso(ev.period_end) || iso(tenant.current_period_end) });
        break;
      case 'payment.failed':
        // keep access for a grace period; do not extend it if a retry fails again
        set({ ...ids, subscription_status: 'past_due', grace_until: tenant.subscription_status === 'past_due' && tenant.grace_until ? tenant.grace_until : addDays(GRACE_DAYS) });
        break;
      case 'invoice.paid':
        if (tenant.subscription_status === 'past_due') set({ subscription_status: 'active', grace_until: null });
        break;
      default: throw bad(`Unsupported event type: ${ev.type}`);
    }
    if (ev.invoice?.id) {
      const i = ev.invoice;
      db.prepare('INSERT OR REPLACE INTO invoices(tenant_id,provider_invoice_id,amount,currency,status,hosted_url,period_start,period_end) VALUES(?,?,?,?,?,?,?,?)')
        .run(tenant.id, String(i.id), Math.round(Number(i.amount) || 0), String(i.currency || 'USD').toUpperCase(), String(i.status || 'paid'), i.url || null, iso(i.period_start), iso(i.period_end));
    }
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  logTenantEvent(tenant.id, `billing:${ev.type}`, { provider, plan: ev.plan });
  return { applied: true, tenant: getTenant(tenant.id) };
}

/** Operator override for manual billing (bank transfer): set plan and status directly. */
export function setSubscription(tenantId, { plan, status = 'active', period_end, interval = 'month' }) {
  const tenant = getTenant(tenantId);
  if (!tenant) throw new HttpError(404, 'Tenant not found');
  if (tenant.is_legacy) throw bad('The original workspace is not billed');
  if (!PLANS[plan]) throw bad('Unknown plan');
  if (!['active', 'past_due', 'canceled', 'trialing'].includes(status)) throw bad('Unknown subscription status');
  platformDb().prepare("UPDATE tenants SET plan=?, subscription_status=?, current_period_end=?, billing_interval=?, billing_provider='manual', grace_until=NULL, updated_at=datetime('now') WHERE id=?")
    .run(plan, status, iso(period_end), interval === 'year' ? 'year' : 'month', tenantId);
  logTenantEvent(tenantId, 'billing:manual', { plan, status, period_end });
  return getTenant(tenantId);
}

export const invoicesFor = (tenantId) => platformDb().prepare('SELECT * FROM invoices WHERE tenant_id=? ORDER BY id DESC LIMIT 50').all(tenantId);

// ---------------------------------------------------------------- payment methods
export const LOCAL_METHODS = { raast: 'Raast', easypaisa: 'Easypaisa', jazzcash: 'JazzCash', sadapay: 'SadaPay', nayapay: 'NayaPay', bank: 'Bank transfer' };

/**
 * Where customers send money for the local methods: the active rows of payment_accounts, managed in the admin console
 * (first start imports BILLING_PK_ACCOUNTS if set). A method is offered only when it has an active account.
 */
export function localAccounts() {
  return platformDb().prepare('SELECT method, account, account_name name, note FROM payment_accounts WHERE active=1 ORDER BY sort_order, id').all().filter((a) => LOCAL_METHODS[a.method]);
}

/** What the signed-in tenant may use to pay. */
export function availableMethods(tenant) {
  const out = [];
  if (stripe.stripeConfigured() || providerName() === 'generic') out.push({ id: 'card', label: 'Card (Visa, Mastercard)', kind: 'online' });
  for (const a of localAccounts()) out.push({ id: a.method, label: LOCAL_METHODS[a.method], kind: 'transfer', account: a.account, account_name: a.name || null, note: a.note || null });
  return out;
}

const origin = (req) => `${req.protocol}://${req.get('host')}`;

/** Start paying for a plan by card. Stripe when configured, otherwise the generic hosted-link flow. */
export async function startCardCheckout(req, { plan, interval = 'month' }) {
  if (!PLANS[plan]) throw bad('Unknown plan');
  if (!['month', 'year'].includes(interval)) throw bad('Interval must be month or year');
  if (stripe.stripeConfigured()) return stripe.createCheckout(req.tenant, { plan, interval, email: req.user.email, origin: origin(req) });
  return startCheckout(req.tenant, { plan, interval, email: req.user.email });
}
export const openCardPortal = (req) => stripe.createPortal(req.tenant, { origin: origin(req) });

const addMonths = (dateStr, n) => {
  const d = new Date(`${dateStr}T00:00:00Z`); const day = d.getUTCDate();
  d.setUTCMonth(d.getUTCMonth() + n);
  if (d.getUTCDate() !== day) d.setUTCDate(0); // 31 Jan + 1 month = 28/29 Feb
  return d.toISOString().slice(0, 10);
};

/** A customer says "I paid PKR X by <method>, reference <ref>". Nothing activates until an operator confirms it arrived. */
export async function submitLocalPayment(tenant, user, { plan, interval = 'month', method, reference, note }) {
  if (!PLANS[plan]) throw bad('Unknown plan');
  if (!['month', 'year'].includes(interval)) throw bad('Interval must be month or year');
  if (!localAccounts().some((a) => a.method === method)) throw bad('This payment method is not available');
  const ref = String(reference || '').trim();
  if (ref.length < 6) throw bad('Enter the transaction ID or reference from your payment receipt');
  const amount = PLANS[plan].price.PKR[interval];
  const db = platformDb();
  if (db.prepare("SELECT 1 FROM payment_submissions WHERE tenant_id=? AND status='pending'").get(tenant.id)) throw bad('You already have a payment waiting for confirmation');
  let id;
  try {
    id = Number(db.prepare('INSERT INTO payment_submissions(tenant_id,plan,interval,method,amount,currency,reference,note,submitted_by) VALUES(?,?,?,?,?,?,?,?,?)')
      .run(tenant.id, plan, interval, method, amount, 'PKR', ref, String(note || '').slice(0, 500) || null, user.email).lastInsertRowid);
  } catch (e) {
    if (/UNIQUE/.test(e.message)) throw new HttpError(409, 'This transaction reference has already been submitted');
    throw e;
  }
  logTenantEvent(tenant.id, 'billing:payment-submitted', { id, method, plan });
  if (process.env.BILLING_OPERATOR_EMAIL) {
    const mail = layout({ heading: 'Payment to confirm', lines: [`${tenant.name} (${tenant.slug}) says they paid PKR ${amount.toLocaleString('en-PK')} by ${LOCAL_METHODS[method]} for ${PLANS[plan].name} (${interval}).`, `Reference: ${ref}`] });
    await sendMail({ to: process.env.BILLING_OPERATOR_EMAIL, subject: `Payment to confirm: ${tenant.name}`, ...mail });
  }
  return { id, amount, currency: 'PKR', status: 'pending' };
}

export const submissionsFor = (tenantId) => platformDb().prepare('SELECT id,plan,interval,method,amount,currency,reference,status,decision_note,created_at,decided_at FROM payment_submissions WHERE tenant_id=? ORDER BY id DESC LIMIT 20').all(tenantId);
export const listSubmissions = (status) => platformDb().prepare(`SELECT s.*, t.slug, t.name tenant_name FROM payment_submissions s JOIN tenants t ON t.id=s.tenant_id ${status ? 'WHERE s.status=?' : ''} ORDER BY s.id DESC LIMIT 100`).all(...(status ? [status] : []));

/** Operator confirms the money arrived: activates the plan for one period (extending from the current period end if still active) and records an invoice. */
export async function approveSubmission(id, decisionNote) {
  const db = platformDb();
  const s = db.prepare('SELECT * FROM payment_submissions WHERE id=?').get(id);
  if (!s) throw new HttpError(404, 'Payment not found');
  if (s.status !== 'pending') throw bad(`This payment was already ${s.status}`);
  const tenant = getTenant(s.tenant_id);
  const today = new Date().toISOString().slice(0, 10);
  const current = tenant.subscription_status === 'active' && tenant.current_period_end && tenant.current_period_end > today && tenant.plan === s.plan ? tenant.current_period_end : today;
  const periodEnd = addMonths(current, s.interval === 'year' ? 12 : 1);
  db.exec('BEGIN IMMEDIATE');
  try {
    db.prepare("UPDATE payment_submissions SET status='approved', decision_note=?, decided_at=datetime('now') WHERE id=?").run(decisionNote || null, id);
    db.prepare("UPDATE tenants SET plan=?, subscription_status='active', current_period_end=?, billing_interval=?, billing_provider=?, grace_until=NULL, updated_at=datetime('now') WHERE id=?")
      .run(s.plan, periodEnd, s.interval, s.method, s.tenant_id);
    db.prepare('INSERT OR IGNORE INTO invoices(tenant_id,provider_invoice_id,amount,currency,status,period_start,period_end) VALUES(?,?,?,?,?,?,?)').run(s.tenant_id, `local-${id}`, s.amount, s.currency, 'paid', current, periodEnd);
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  logTenantEvent(s.tenant_id, 'billing:payment-approved', { id, method: s.method });
  const mail = layout({ heading: 'Payment received', lines: [`Thank you. We received your ${LOCAL_METHODS[s.method]} payment and your ${PLANS[s.plan].name} plan is active until ${periodEnd}.`] });
  await sendMail({ to: s.submitted_by, subject: 'Your payment was confirmed', ...mail });
  return getTenant(s.tenant_id);
}

export async function rejectSubmission(id, decisionNote) {
  const db = platformDb();
  const s = db.prepare('SELECT * FROM payment_submissions WHERE id=?').get(id);
  if (!s) throw new HttpError(404, 'Payment not found');
  if (s.status !== 'pending') throw bad(`This payment was already ${s.status}`);
  if (!String(decisionNote || '').trim()) throw bad('Say why it was rejected so the customer can fix it');
  db.prepare("UPDATE payment_submissions SET status='rejected', decision_note=?, decided_at=datetime('now') WHERE id=?").run(decisionNote, id);
  logTenantEvent(s.tenant_id, 'billing:payment-rejected', { id });
  const mail = layout({ heading: 'We could not confirm your payment', lines: [`Reference ${s.reference}: ${decisionNote}`, 'Please check the details and submit again, or contact us.'] });
  await sendMail({ to: s.submitted_by, subject: 'We could not confirm your payment', ...mail });
}

/** Find the tenant a Stripe object belongs to when it carries no metadata (e.g. invoices). */
export function tenantByProviderIds(customerId, subscriptionId) {
  const r = platformDb().prepare('SELECT id FROM tenants WHERE (provider_customer_id IS NOT NULL AND provider_customer_id=?) OR (provider_subscription_id IS NOT NULL AND provider_subscription_id=?)').get(customerId || null, subscriptionId || null);
  return r?.id ?? null;
}
