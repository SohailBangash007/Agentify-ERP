// Plans, limits and the billing state machine. Pure functions over a tenant row (no I/O) so they are easy to test.
//
// PRICES BELOW ARE PLACEHOLDERS: edit them (and the limits) before launch. A `null` limit means unlimited.
import { val } from '../db.js';
import { HttpError } from '../util.js';

export const PLANS = {
  starter:    { name: 'Starter',    seats: 5,    projects: 3,    price: { USD: { month: 29, year: 290 },   PKR: { month: 8000, year: 80000 } } },
  growth:     { name: 'Growth',     seats: 25,   projects: 25,   price: { USD: { month: 79, year: 790 },   PKR: { month: 22000, year: 220000 } } },
  enterprise: { name: 'Enterprise', seats: null, projects: null, price: { USD: { month: 199, year: 1990 }, PKR: { month: 55000, year: 550000 } } },
};
export const TRIAL_LIMITS = { name: 'Free trial', seats: PLANS.growth.seats, projects: PLANS.growth.projects };
/** The original install is not metered. */
const LEGACY_LIMITS = { name: 'Unlimited', seats: null, projects: null };
export const GRACE_DAYS = 7;

const day = (iso) => String(iso || '').slice(0, 10);
const todayUtc = () => new Date().toISOString().slice(0, 10);
const addDaysIso = (d, n) => new Date(Date.parse(`${d}T00:00:00Z`) + n * 864e5).toISOString().slice(0, 10);
const daysBetween = (a, b) => Math.round((Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`)) / 864e5);

/**
 * What a tenant may do right now.
 *  trialing  -> trial limits until trial_ends_at, then locked (read-only) until they subscribe
 *  active    -> their plan
 *  past_due  -> their plan for GRACE_DAYS after the failed payment, then locked
 *  canceled  -> their plan until the paid period ends, then locked
 * "Locked" means read-only: nothing is ever deleted for non-payment.
 */
export function billingState(tenant, today = todayUtc()) {
  if (!tenant) return { plan: null, status: 'none', locked: false, limits: LEGACY_LIMITS };
  if (tenant.is_legacy) return { plan: 'legacy', status: 'active', locked: false, limits: LEGACY_LIMITS };
  const sub = tenant.subscription_status || 'trialing';
  const plan = PLANS[tenant.plan] ? tenant.plan : null;
  const limits = plan ? PLANS[plan] : TRIAL_LIMITS;
  if (tenant.status === 'cancelled') return { plan, status: 'canceled', locked: true, reason: 'cancelled', limits };
  if (sub === 'active') return { plan, status: 'active', locked: false, limits, period_end: tenant.current_period_end || null };
  if (sub === 'past_due') {
    const until = tenant.grace_until ? day(tenant.grace_until) : addDaysIso(today, GRACE_DAYS);
    const locked = today > until;
    return { plan, status: 'past_due', locked, reason: locked ? 'payment_failed' : undefined, limits, grace_until: until, period_end: tenant.current_period_end || null };
  }
  if (sub === 'canceled') {
    const end = day(tenant.current_period_end);
    const locked = !end || today > end;
    return { plan, status: 'canceled', locked, reason: locked ? 'subscription_ended' : undefined, limits, period_end: end || null };
  }
  // trialing
  const end = day(tenant.trial_ends_at);
  const locked = !!end && today > end;
  return { plan: null, status: 'trialing', locked, reason: locked ? 'trial_ended' : undefined, limits: TRIAL_LIMITS, trial_ends_at: end || null, days_left: end ? Math.max(0, daysBetween(today, end)) : null };
}

export const planCatalog = () => Object.entries(PLANS).map(([id, p]) => ({ id, name: p.name, seats: p.seats, projects: p.projects, price: p.price }));

export class PlanLimitError extends HttpError {
  constructor(message, code, extra = {}) { super(402, message, { code, ...extra }); }
}

/** Counts that plans limit: active staff logins (+ pending invitations, so you cannot invite past the limit) and projects. */
export function usage() {
  const seats = val('SELECT COUNT(*) FROM users u JOIN roles r ON r.id=u.role_id WHERE u.active=1 AND r.portal=0');
  const invited = val("SELECT COUNT(*) FROM auth_tokens WHERE kind='invite' AND used_at IS NULL AND expires_at>?", new Date().toISOString());
  return { seats, invited, projects: val('SELECT COUNT(*) FROM projects') };
}

export function assertSeatAvailable(tenant, { includeInvites = true, extra = 1 } = {}) {
  const st = billingState(tenant);
  if (st.limits.seats == null) return;
  const u = usage();
  if (u.seats + (includeInvites ? u.invited : 0) + extra > st.limits.seats) {
    throw new PlanLimitError(`Your ${st.limits.name} plan allows ${st.limits.seats} team members. Upgrade to add more.`, 'seat_limit', { limit: st.limits.seats });
  }
}

export function assertProjectAvailable(tenant) {
  const st = billingState(tenant);
  if (st.limits.projects == null) return;
  if (usage().projects + 1 > st.limits.projects) {
    throw new PlanLimitError(`Your ${st.limits.name} plan allows ${st.limits.projects} projects. Upgrade to add more.`, 'project_limit', { limit: st.limits.projects });
  }
}

const LOCK_MESSAGES = {
  trial_ended: 'Your free trial has ended. Your data is safe and read-only; choose a plan to keep editing.',
  payment_failed: 'Your last payment failed and the grace period has ended. Your data is safe and read-only; update your payment to continue.',
  subscription_ended: 'Your subscription has ended. Your data is safe and read-only; renew to continue.',
  cancelled: 'This workspace has been cancelled. Contact support to reactivate it.',
};
export const lockMessage = (reason) => LOCK_MESSAGES[reason] || 'This workspace is read-only until billing is up to date.';

/**
 * Express guard: while a workspace is locked, reads still work (people can see and export their data) but writes are
 * refused with 402. Sign-in, billing, and the public website's visitor forms stay open.
 */
export function billingGuard(req, _res, next) {
  const t = req.tenant;
  if (!t) return next();
  const st = billingState(t);
  const open = ['GET', 'HEAD', 'OPTIONS'].includes(req.method) || /^\/(auth|billing|site|public)(\/|$)/.test(req.path);
  if (st.locked && !open) return next(new HttpError(402, lockMessage(st.reason), { code: 'billing_locked', reason: st.reason }));
  if (req.method === 'POST' && req.path === '/projects') { try { assertProjectAvailable(t); } catch (e) { return next(e); } }
  next();
}
