// Platform admin console API (mounted at /api/platform/admin). Sign-in, payment settings (Stripe keys, local payment accounts).
import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { asyncH, bad, HttpError } from '../util.js';
import { platformDb, BASE_DOMAIN, isMultiTenant } from '../platform.js';
import { COOKIE, login, loginMfa, changePassword, requireOperator, onPlatformHost, twofaStatus, twofaSetup, twofaEnable, twofaDisable } from '../services/platformAuth.js';
import { stripeView, saveStripe, stripeConfig, STRIPE_MODES, audit } from '../services/platformConfig.js';
import { testConnection } from '../services/stripe.js';
import { LOCAL_METHODS } from '../services/billing.js';
import { runBackup, listBackups, backupDir } from '../services/backup.js';

const r = Router();
const limiter = rateLimit({ windowMs: 60_000, limit: Number(process.env.LOGIN_LIMIT) || 10, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many attempts. Try again in a minute.' } });
const cookieOpts = { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production', maxAge: 8 * 3600 * 1000 };

r.post('/login', limiter, asyncH((req, res) => {
  if (!onPlatformHost(req)) throw new HttpError(404, 'Not found');
  if (req.headers['x-requested-with'] !== 'ERP') throw new HttpError(403, 'CSRF check failed');
  const out = login(req.body?.email, req.body?.password);
  if (out.mfa_token) return res.json({ mfa_required: true, mfa_token: out.mfa_token });
  res.cookie(COOKIE, out.token, cookieOpts);
  audit(out.admin.email, 'login');
  res.json(out.admin);
}));
r.post('/login/mfa', limiter, asyncH((req, res) => {
  if (!onPlatformHost(req)) throw new HttpError(404, 'Not found');
  if (req.headers['x-requested-with'] !== 'ERP') throw new HttpError(403, 'CSRF check failed');
  const { admin, token } = loginMfa(req.body?.mfa_token, req.body?.code);
  res.cookie(COOKIE, token, cookieOpts);
  audit(admin.email, 'login (2fa)');
  res.json(admin);
}));
const adminOnly = (req) => { if (req.operator.via !== 'session') throw bad('Sign in as an admin to manage two-factor sign-in'); };
r.get('/2fa', requireOperator, (req, res) => { adminOnly(req); res.json(twofaStatus(req.operator.id)); });
r.post('/2fa/setup', requireOperator, limiter, asyncH(async (req, res) => { adminOnly(req); res.json(await twofaSetup(req.operator)); }));
r.post('/2fa/enable', requireOperator, limiter, asyncH((req, res) => { adminOnly(req); const codes = twofaEnable(req.operator.id, req.body?.code); audit(req.operator.email, '2fa-enabled'); res.json({ ok: true, recovery_codes: codes }); }));
r.post('/2fa/disable', requireOperator, limiter, asyncH((req, res) => { adminOnly(req); twofaDisable(req.operator.id, req.body?.password, req.body?.code); audit(req.operator.email, '2fa-disabled'); res.json({ ok: true }); }));
r.post('/logout', requireOperator, (req, res) => { audit(req.operator.email, 'logout'); res.clearCookie(COOKIE); res.json({ ok: true }); });
r.get('/me', requireOperator, (req, res) => res.json({ email: req.operator.email, name: req.operator.name || null, via: req.operator.via, base_domain: BASE_DOMAIN || null, multi_tenant: isMultiTenant() }));
r.post('/change-password', requireOperator, limiter, asyncH((req, res) => {
  if (req.operator.via !== 'session') throw bad('Sign in as an admin to change a password');
  const { token } = changePassword(req.operator.id, req.body?.current, req.body?.next);
  res.cookie(COOKIE, token, cookieOpts); audit(req.operator.email, 'password-changed'); res.json({ ok: true });
}));

// ---- Stripe
const webhookUrl = (req) => `${req.protocol}://${req.get('host')}/api/platform/billing/webhook/stripe`;
r.get('/settings/stripe', requireOperator, (req, res) => res.json({ ...stripeView(), webhook_url: webhookUrl(req) }));
r.put('/settings/stripe', requireOperator, asyncH((req, res) => {
  const out = saveStripe(req.body || {}, req.operator.email);
  if (out.errors.length) throw bad(out.errors.join('. '), { errors: out.errors });
  res.json({ ...stripeView(), webhook_url: webhookUrl(req) });
}));
/** Read-only call to Stripe with the saved secret key for that mode, so a wrong key is found before a customer pays. */
r.post('/settings/stripe/test', requireOperator, asyncH(async (req, res) => {
  const mode = STRIPE_MODES.includes(req.body?.mode) ? req.body.mode : stripeConfig().mode;
  const out = await testConnection(stripeConfig().modes[mode].secret_key);
  if (out.ok && out.livemode !== (mode === 'live')) return res.json({ ok: false, error: `This key is a ${out.livemode ? 'live' : 'test'} key but is saved as ${mode}` });
  res.json({ mode, ...out });
}));

// ---- Local payment accounts (Raast, Easypaisa, JazzCash, SadaPay, NayaPay, bank)
const accountView = (a) => ({ id: a.id, method: a.method, label: LOCAL_METHODS[a.method] || a.method, account: a.account, account_name: a.account_name, note: a.note, active: !!a.active, sort_order: a.sort_order });
const cleanAccount = (b, partial = false) => {
  const out = {};
  if (!partial || b.method !== undefined) { if (!LOCAL_METHODS[b.method]) throw bad(`Method must be one of: ${Object.keys(LOCAL_METHODS).join(', ')}`); out.method = b.method; }
  if (!partial || b.account !== undefined) { const a = String(b.account || '').trim(); if (a.length < 3 || a.length > 60) throw bad('Account number / ID is required (3 to 60 characters)'); out.account = a; }
  if (b.account_name !== undefined) out.account_name = String(b.account_name || '').trim().slice(0, 80) || null;
  if (b.note !== undefined) out.note = String(b.note || '').trim().slice(0, 200) || null;
  if (b.active !== undefined) out.active = b.active ? 1 : 0;
  if (b.sort_order !== undefined) out.sort_order = Math.trunc(Number(b.sort_order)) || 0;
  return out;
};
r.get('/payment-accounts', requireOperator, (_req, res) => res.json({ methods: LOCAL_METHODS, accounts: platformDb().prepare('SELECT * FROM payment_accounts ORDER BY sort_order, id').all().map(accountView) }));
r.post('/payment-accounts', requireOperator, asyncH((req, res) => {
  const c = cleanAccount(req.body || {});
  const id = Number(platformDb().prepare('INSERT INTO payment_accounts(method,account,account_name,note,active,sort_order) VALUES(?,?,?,?,?,?)').run(c.method, c.account, c.account_name ?? null, c.note ?? null, c.active ?? 1, c.sort_order ?? 0).lastInsertRowid);
  audit(req.operator.email, 'payment-account-added', { id, method: c.method });
  res.status(201).json(accountView(platformDb().prepare('SELECT * FROM payment_accounts WHERE id=?').get(id)));
}));
r.put('/payment-accounts/:id', requireOperator, asyncH((req, res) => {
  const cur = platformDb().prepare('SELECT * FROM payment_accounts WHERE id=?').get(Number(req.params.id));
  if (!cur) throw new HttpError(404, 'Account not found');
  const c = cleanAccount(req.body || {}, true);
  const keys = Object.keys(c);
  if (keys.length) platformDb().prepare(`UPDATE payment_accounts SET ${keys.map((k) => `${k}=?`).join(',')}, updated_at=datetime('now') WHERE id=?`).run(...keys.map((k) => c[k]), cur.id);
  audit(req.operator.email, 'payment-account-edited', { id: cur.id, fields: keys });
  res.json(accountView(platformDb().prepare('SELECT * FROM payment_accounts WHERE id=?').get(cur.id)));
}));
r.delete('/payment-accounts/:id', requireOperator, asyncH((req, res) => {
  const n = platformDb().prepare('DELETE FROM payment_accounts WHERE id=?').run(Number(req.params.id)).changes;
  if (!n) throw new HttpError(404, 'Account not found');
  audit(req.operator.email, 'payment-account-deleted', { id: Number(req.params.id) });
  res.json({ ok: true });
}));

// ---- Backups
r.get('/backups', requireOperator, (_req, res) => res.json({ dir: backupDir(), backups: listBackups(), keep: Number(process.env.BACKUP_KEEP) || 14, every_hours: Number(process.env.BACKUP_EVERY_HOURS) || 24, enabled: process.env.BACKUP_ENABLED !== '0', uploads: process.env.BACKUP_UPLOADS === '1' }));
r.post('/backups/run', requireOperator, limiter, asyncH((req, res) => { const out = runBackup(); audit(req.operator.email, 'backup-run', { name: out.name }); res.json(out); }));
r.get('/audit', requireOperator, (_req, res) => res.json(platformDb().prepare('SELECT * FROM platform_audit ORDER BY id DESC LIMIT 100').all()));

export default r;
