import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { uploadDir, get } from './db.js';
import { scheduleBackups } from './services/backup.js';
import { tenantContext, bootstrapTenants, forEachTenant } from './platform.js';
import { ensureFirstAdmin } from './services/platformAuth.js';
import platformRoutes from './routes/platform.js';
import billing from './routes/billing.js';
import { billingGuard } from './services/plans.js';
import { authenticate, csrfGuard, requireStaff } from './rbac.js';
import { HttpError } from './util.js';
import { runReminders } from './services/reminders.js';
import { runGoalReminders } from './services/goals.js';
import goals, { push } from './routes/goals.js';
import assistant from './routes/assistant.js';
import site from './routes/site.js';
import siteAdmin from './routes/siteAdmin.js';
import staff from './routes/staff.js';
import insights from './routes/insights.js';
import tenders from './routes/tenders.js';
import listings from './routes/listings.js';
import seo, { robots, sitemap } from './routes/seo.js';
import claims, { feed as paymentFeed } from './routes/claims.js';
import vendorPortal from './routes/vendorPortal.js';
import content, { contentReminders } from './routes/content.js';
import promos from './routes/promos.js';

import auth from './routes/auth.js';
import settings from './routes/settings.js';
import crm from './routes/crm.js';
import agents from './routes/agents.js';
import properties from './routes/properties.js';
import projects from './routes/projects.js';
import sales from './routes/sales.js';
import accounting from './routes/accounting.js';
import hrm from './routes/hrm.js';
import reports from './routes/reports.js';
import dashboard from './routes/dashboard.js';
import misc from './routes/misc.js';
import portal from './routes/portal.js';
import pub from './routes/public.js';

const here = path.dirname(fileURLToPath(import.meta.url));

export function createApp() {
  bootstrapTenants();
  ensureFirstAdmin();
  const app = express();
  app.set('trust proxy', 1);
  app.disable('x-powered-by');
  app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], imgSrc: ["'self'", 'data:', 'blob:', 'https:'], mediaSrc: ["'self'", 'blob:', 'https:'], styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
    fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'], scriptSrc: ["'self'"], frameSrc: ["'self'", 'https://www.youtube.com', 'https://www.google.com', 'https://www.openstreetmap.org'], connectSrc: ["'self'"], workerSrc: ["'self'"], manifestSrc: ["'self'"],
    // Only force https in production; on plain http://localhost it can break service-worker and asset fetches.
    upgradeInsecureRequests: process.env.NODE_ENV === 'production' ? [] : null } }, hsts: process.env.NODE_ENV === 'production', crossOriginResourcePolicy: { policy: 'cross-origin' } }));
  // the billing webhook is signed over the exact bytes, so keep them for that one route
  app.use(express.json({ limit: '2mb', verify: (req, _res, buf) => { if (req.originalUrl.startsWith('/api/platform/billing/webhook')) req.rawBody = buf; } }));
  app.use(cookieParser());

  // Platform (control plane) API: signup, tenant admin. Never tenant-scoped.
  app.use('/api/platform', platformRoutes);

  // Everything below runs inside the tenant that owns the request's host name. Placed after the body parsers so the
  // tenant context is not lost in stream callbacks.
  app.use(tenantContext);

  // Public website API: key-authenticated, CORS-open (no cookies involved)
  app.use('/api/public', (req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-API-Key');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
  }, pub);

  app.use('/api', rateLimit({ windowMs: 60_000, limit: 900, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many requests' } }));
  app.use('/api', authenticate, csrfGuard);
  app.use('/api', billingGuard);

  // Listing media (images/videos) is public by design; documents are NOT served statically.
  app.use('/uploads/media', (req, res, next) => {
    if (!req.tenant) return next();
    express.static(path.join(uploadDir(), 'media'), { maxAge: '7d', setHeaders: (r) => r.setHeader('X-Content-Type-Options', 'nosniff') })(req, res, next);
  });
  // direct links to /uploads/<path> where path already contains the "media/" folder
  app.get('/health', (_req, res) => res.json({ ok: true, db: !!get('SELECT 1 v') }));

  app.use('/api/auth', auth);
  app.use('/api/billing', billing);
  app.use('/api/site', site);
  app.use('/api/site-admin', siteAdmin);
  app.use('/api/goals', goals);
  app.use('/api/staff', staff);
  app.use('/api/insights', insights);
  app.use('/api/tenders', tenders);
  app.use('/api/listings', listings);
  app.use('/api/seo', seo);
  app.use('/api/payment-claims', claims);
  app.use('/api/payment-feed', paymentFeed);
  app.use('/api/vendor', vendorPortal);
  app.use('/api/content', content);
  app.use('/api/promos', promos);
  app.use('/api/push', push);
  app.use('/api/assistant', assistant);
  app.use('/api/portal', portal);
  app.use('/api/settings', settings);
  app.use('/api/agents', agents);
  app.use('/api/dashboard', dashboard);
  app.use('/api/reports', reports);
  app.use('/api/properties', properties);
  app.use('/api/hrm', hrm);
  app.use('/api', crm);
  app.use('/api', projects);
  app.use('/api', sales);
  app.use('/api/accounting', accounting);
  app.use('/api', misc);
  app.use('/api', (_req, _res, next) => next(new HttpError(404, 'Endpoint not found')));

  app.get('/sitemap.xml', sitemap);
  app.get('/robots.txt', robots);

  // Serve the built SPA when present
  const dist = path.join(here, '..', '..', 'client', 'dist');
  if (fs.existsSync(dist)) {
    app.use(express.static(dist));
    app.get(/^\/(?!api|uploads).*/, (_req, res) => res.sendFile(path.join(dist, 'index.html')));
  }

  app.use((err, req, res, _next) => {
    if (err instanceof HttpError) return res.status(err.status).json({ error: err.message, ...(err.extra || {}) });
    if (err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: 'File is too large' });
    if (err.name === 'MulterError') return res.status(400).json({ error: err.message });
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON' });
    if (/UNIQUE constraint failed/.test(err.message || '')) return res.status(409).json({ error: 'A record with this unique value already exists' });
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  });
  return app;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const port = Number(process.env.PORT) || 4000;
  createApp().listen(port, () => console.log(`Expert ERP API listening on http://localhost:${port}`));
  const tick = () => forEachTenant(() => { runReminders(); runGoalReminders(); contentReminders(); });
  tick();
  scheduleBackups();
  setInterval(tick, 30 * 60 * 1000).unref(); // goal nudges are once-per-day via dedupe keys
}
